package com.zomato.tracker.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zomato.tracker.data.DeliveryDatabase
import com.zomato.tracker.model.DeliveryRecord
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.round

class DeliveryViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = DeliveryDatabase.getDatabase(application).deliveryDao()
    private val sharedPrefs = application.getSharedPreferences("zomato_prefs", Context.MODE_PRIVATE)

    val allRecords: StateFlow<List<DeliveryRecord>> = dao.getAllRecords()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedDate = MutableStateFlow(LocalDate.now().format(DateTimeFormatter.ISO_DATE))
    val earningsInput = MutableStateFlow("")
    val kmInput = MutableStateFlow("")
    val hoursInput = MutableStateFlow("")
    val petrolPriceInput = MutableStateFlow(sharedPrefs.getFloat("last_petrol_price", 104.0f).toString())
    val mileageInput = MutableStateFlow(sharedPrefs.getFloat("last_mileage", 55.0f).toString())
    val notesInput = MutableStateFlow("")
    val saveStatusMessage = MutableStateFlow<String?>(null)

    fun onDateSelected(date: String) {
        selectedDate.value = date
        viewModelScope.launch {
            val existing = dao.getRecordByDate(date)
            if (existing != null) {
                earningsInput.value = existing.totalEarnings.toString()
                kmInput.value = existing.distanceKm.toString()
                hoursInput.value = existing.workingHours.toString()
                petrolPriceInput.value = existing.petrolPrice.toString()
                mileageInput.value = existing.mileage.toString()
                notesInput.value = existing.notes
            }
        }
    }

    fun saveCurrentRecord(onSuccess: (Boolean) -> Unit) {
        val date = selectedDate.value
        val earnings = earningsInput.value.toDoubleOrNull() ?: 0.0
        val km = kmInput.value.toDoubleOrNull() ?: 0.0
        val hours = hoursInput.value.toDoubleOrNull() ?: 0.0
        val petrolPrice = petrolPriceInput.value.toDoubleOrNull() ?: 104.0
        val mileage = mileageInput.value.toDoubleOrNull() ?: 55.0

        if (earnings <= 0.0 && km <= 0.0) {
            saveStatusMessage.value = "Kripya kamai ya kilometre bharein!"
            return
        }

        val petrolUsed = if (mileage > 0) km / mileage else 0.0
        val petrolCost = petrolUsed * petrolPrice
        val netEarnings = earnings - petrolCost
        val ratePerHour = if (hours > 0) netEarnings / hours else 0.0
        val ratePerKm = if (km > 0) netEarnings / km else 0.0

        val record = DeliveryRecord(
            date = date,
            totalEarnings = round2(earnings),
            distanceKm = round2(km),
            workingHours = round2(hours),
            petrolPrice = round2(petrolPrice),
            mileage = round2(mileage),
            petrolUsedLitres = round2(petrolUsed),
            petrolCost = round2(petrolCost),
            netEarnings = round2(netEarnings),
            earningsPerHour = round2(ratePerHour),
            earningsPerKm = round2(ratePerKm),
            notes = notesInput.value
        )

        viewModelScope.launch {
            val existing = dao.getRecordByDate(date)
            val isUpdate = existing != null
            dao.upsertRecord(record)

            sharedPrefs.edit()
                .putFloat("last_petrol_price", petrolPrice.toFloat())
                .putFloat("last_mileage", mileage.toFloat())
                .apply()

            saveStatusMessage.value = if (isUpdate) "Record safalta se update ho gaya! ✓" else "Naya record save ho gaya! ✓"
            onSuccess(isUpdate)
        }
    }

    fun deleteRecord(record: DeliveryRecord) {
        viewModelScope.launch {
            dao.deleteRecord(record)
        }
    }

    private fun round2(v: Double): Double = round(v * 100) / 100
}