package com.zomato.tracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zomato.tracker.model.DeliveryRecord
import com.zomato.tracker.viewmodel.DeliveryViewModel

@Composable
fun HistoryScreen(
    viewModel: DeliveryViewModel,
    onEditRecord: (DeliveryRecord) -> Unit,
    modifier: Modifier = Modifier
) {
    val records by viewModel.allRecords.collectAsState()
    var recordToDelete by remember { mutableStateOf<DeliveryRecord?>(null) }

    if (records.isEmpty()) {
        Box(modifier = modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Inbox, contentDescription = null, modifier = Modifier.size(64.dp), tint = Color(0xFF64748B))
                Spacer(modifier = Modifier.height(16.dp))
                Text("Koi Delivery Record Nahi Hai", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                Text("Pehla record save karne ke liye 'Daily Entry' par jayein.", color = Color(0xFF94A3B8), fontSize = 14.sp)
            }
        }
    } else {
        LazyColumn(modifier = modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(records, key = { it.date }) { record ->
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(text = record.date, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                            Row {
                                IconButton(onClick = { onEditRecord(record) }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color(0xFF38BDF8))
                                }
                                IconButton(onClick = { recordToDelete = record }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444))
                                }
                            }
                        }
                        HorizontalDivider(color = Color(0xFF334155), modifier = Modifier.padding(vertical = 8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Kamai: ₹${"%.2f".format(record.totalEarnings)}", color = Color.White)
                            Text("Petrol: ₹${"%.2f".format(record.petrolCost)}", color = Color(0xFFF59E0B))
                            Text("Bachat: ₹${"%.2f".format(record.netEarnings)}", color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    if (recordToDelete != null) {
        AlertDialog(
            onDismissRequest = { recordToDelete = null },
            title = { Text("Record Hatao?") },
            text = { Text("Kya aap ${recordToDelete?.date} ka record delete karna chahte hain?") },
            confirmButton = {
                TextButton(onClick = {
                    recordToDelete?.let { viewModel.deleteRecord(it) }
                    recordToDelete = null
                }) {
                    Text("Delete", color = Color(0xFFEF4444))
                }
            },
            dismissButton = {
                TextButton(onClick = { recordToDelete = null }) { Text("Cancel") }
            }
        )
    }
}