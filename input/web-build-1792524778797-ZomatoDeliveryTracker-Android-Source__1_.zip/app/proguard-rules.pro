# ProGuard and R8 rules for Zomato Delivery Tracker
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**