# Zomato Delivery Tracker (Native Android)
Complete native Android Kotlin Jetpack Compose application with Room local database.

### Tested & Validated Gradle Setup
- Gradle: 8.6
- Android Gradle Plugin (AGP): 8.3.1
- Kotlin: 1.9.22
- KSP: 1.9.22-1.0.18
- Version Catalog: `gradle/libs.versions.toml`
- Target SDK: 34 (Android 14)
- Min SDK: 24 (Android 7.0)

### How to Build:
Run:
```bash
./gradlew assembleDebug
```
The debug APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.
