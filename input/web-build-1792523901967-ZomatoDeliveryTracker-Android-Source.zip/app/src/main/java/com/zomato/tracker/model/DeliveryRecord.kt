package com.zomato.tracker.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Native Room Entity representing a single day's delivery performance.
 * PrimaryKey is the ISO date string (YYYY-MM-DD) to prevent accidental duplicates.
 */
@Entity(tableName = "delivery_records")
data class DeliveryRecord(
    @PrimaryKey
    val date: String, // YYYY-MM-DD
    val totalEarnings: Double, // ₹ (including incentives)
    val distanceKm: Double, // kilometres ridden
    val workingHours: Double, // delivery working hours (decimal, e.g. 4.5)
    val petrolPrice: Double, // ₹ per litre (default 104.0)
    val mileage: Double, // km per litre (default 55.0)
    val petrolUsedLitres: Double, // km / mileage
    val petrolCost: Double, // petrolUsedLitres * petrolPrice
    val netEarnings: Double, // totalEarnings - petrolCost
    val earningsPerHour: Double, // netEarnings / workingHours
    val earningsPerKm: Double, // netEarnings / distanceKm
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)