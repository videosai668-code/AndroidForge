package com.zomato.tracker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zomato.tracker.viewmodel.DeliveryViewModel
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters

@Composable
fun SummaryScreen(viewModel: DeliveryViewModel, modifier: Modifier = Modifier) {
    val records by viewModel.allRecords.collectAsState()
    var isWeeklyView by remember { mutableStateOf(true) }
    var weekOffset by remember { mutableIntStateOf(0) }

    val today = remember { LocalDate.now() }
    val targetMonday = remember(weekOffset) {
        today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).plusWeeks(weekOffset.toLong())
    }
    val weekDates = remember(targetMonday) {
        (0..6).map { targetMonday.plusDays(it.toLong()).format(DateTimeFormatter.ISO_DATE) }
    }

    val weekRecords = records.filter { it.date in weekDates }
    val weekTotalEarnings = weekRecords.sumOf { it.totalEarnings }
    val weekTotalPetrol = weekRecords.sumOf { it.petrolCost }
    val weekTotalNet = weekRecords.sumOf { it.netEarnings }
    val weekTotalHours = weekRecords.sumOf { it.workingHours }

    Column(modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        // Weekly View Toggle
        Row(modifier = Modifier.fillMaxWidth().background(Color(0xFF0F172A), RoundedCornerShape(12.dp)).padding(4.dp)) {
            Button(
                onClick = { isWeeklyView = true },
                colors = ButtonDefaults.buttonColors(containerColor = if (isWeeklyView) Color(0xFFE23744) else Color.Transparent),
                modifier = Modifier.weight(1f)
            ) { Text("Weekly View") }
            Button(
                onClick = { isWeeklyView = false },
                colors = ButtonDefaults.buttonColors(containerColor = if (!isWeeklyView) Color(0xFFE23744) else Color.Transparent),
                modifier = Modifier.weight(1f)
            ) { Text("Monthly View") }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Current vs Past Week Toggle
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { weekOffset = 0 }, modifier = Modifier.weight(1f)) {
                Text("Is Hafte (Current)", color = if (weekOffset == 0) Color(0xFFE23744) else Color.White)
            }
            OutlinedButton(onClick = { weekOffset = -1 }, modifier = Modifier.weight(1f)) {
                Text("Pichle Hafte (Past)", color = if (weekOffset == -1) Color(0xFFE23744) else Color.White)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Aggregated Card
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(if (weekOffset == 0) "IS HAFTE KA HISAAB" else "PICHLE HAFTE KA HISAAB", color = Color(0xFF94A3B8), fontSize = 12.sp)
                Text("₹ ${"%.2f".format(weekTotalNet)}", color = Color(0xFF10B981), fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Kamai: ₹${"%.2f".format(weekTotalEarnings)}", color = Color.White)
                    Text("Petrol: ₹${"%.2f".format(weekTotalPetrol)}", color = Color(0xFFF59E0B))
                    Text("Ghante: ${"%.1f".format(weekTotalHours)}h", color = Color(0xFF38BDF8))
                }
            }
        }
    }
}