package com.zomato.tracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zomato.tracker.viewmodel.DeliveryViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyEntryScreen(
    viewModel: DeliveryViewModel,
    modifier: Modifier = Modifier
) {
    val selectedDate by viewModel.selectedDate.collectAsState()
    val earningsInput by viewModel.earningsInput.collectAsState()
    val kmInput by viewModel.kmInput.collectAsState()
    val hoursInput by viewModel.hoursInput.collectAsState()
    val petrolPriceInput by viewModel.petrolPriceInput.collectAsState()
    val mileageInput by viewModel.mileageInput.collectAsState()

    val earnings = earningsInput.toDoubleOrNull() ?: 0.0
    val km = kmInput.toDoubleOrNull() ?: 0.0
    val hours = hoursInput.toDoubleOrNull() ?: 0.0
    val petrolPrice = petrolPriceInput.toDoubleOrNull() ?: 104.0
    val mileage = mileageInput.toDoubleOrNull() ?: 55.0

    val petrolUsed = if (mileage > 0) km / mileage else 0.0
    val petrolCost = petrolUsed * petrolPrice
    val netEarnings = earnings - petrolCost
    val earningsPerHour = if (hours > 0) netEarnings / hours else 0.0
    val earningsPerKm = if (km > 0) netEarnings / km else 0.0

    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Net Profit Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ASLI BACHAT (NET)", color = Color(0xFF94A3B8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("₹ ${"%.2f".format(netEarnings)}", color = Color(0xFF10B981), fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                Text("Petrol: ₹${"%.2f".format(petrolCost)}  |  ₹${"%.2f".format(earningsPerHour)}/hr", color = Color(0xFF94A3B8), fontSize = 12.sp)
            }
        }

        OutlinedTextField(
            value = selectedDate,
            onValueChange = { viewModel.onDateSelected(it) },
            label = { Text("Tareekh (YYYY-MM-DD)") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = earningsInput,
            onValueChange = { viewModel.earningsInput.value = it },
            label = { Text("Kul Zomato Kamai (₹)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = kmInput,
                onValueChange = { viewModel.kmInput.value = it },
                label = { Text("KM Chali") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = hoursInput,
                onValueChange = { viewModel.hoursInput.value = it },
                label = { Text("Ghante (e.g. 4.5)") },
                modifier = Modifier.weight(1f)
            )
        }

        Button(
            onClick = { viewModel.saveCurrentRecord {} },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE23744)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Text("Record Save Karein", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}