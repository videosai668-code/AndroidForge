package com.zomato.tracker.data

import androidx.room.*
import com.zomato.tracker.model.DeliveryRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface DeliveryDao {
    @Query("SELECT * FROM delivery_records ORDER BY date DESC")
    fun getAllRecords(): Flow<List<DeliveryRecord>>

    @Query("SELECT * FROM delivery_records WHERE date = :date LIMIT 1")
    suspend fun getRecordByDate(date: String): DeliveryRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRecord(record: DeliveryRecord)

    @Delete
    suspend fun deleteRecord(record: DeliveryRecord)

    @Query("DELETE FROM delivery_records WHERE date = :date")
    suspend fun deleteByDate(date: String)

    @Query("SELECT * FROM delivery_records WHERE date LIKE :monthPrefix || '%' ORDER BY date DESC")
    fun getRecordsForMonth(monthPrefix: String): Flow<List<DeliveryRecord>>
}