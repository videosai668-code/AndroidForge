package com.zomato.tracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.zomato.tracker.ui.DailyEntryScreen
import com.zomato.tracker.ui.HistoryScreen
import com.zomato.tracker.ui.SummaryScreen
import com.zomato.tracker.viewmodel.DeliveryViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: DeliveryViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFE23744),
                    secondary = Color(0xFF10B981),
                    background = Color(0xFF0F172A),
                    surface = Color(0xFF1E293B)
                )
            ) {
                var currentTab by remember { mutableIntStateOf(0) }

                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text("Zomato Delivery Tracker", color = Color.White) },
                            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFE23744))
                        )
                    },
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF0B1120)) {
                            NavigationBarItem(selected = currentTab == 0, onClick = { currentTab = 0 }, icon = { Icon(Icons.Default.AddCircle, null) }, label = { Text("Daily Entry") })
                            NavigationBarItem(selected = currentTab == 1, onClick = { currentTab = 1 }, icon = { Icon(Icons.Default.History, null) }, label = { Text("Itihaas") })
                            NavigationBarItem(selected = currentTab == 2, onClick = { currentTab = 2 }, icon = { Icon(Icons.Default.Assessment, null) }, label = { Text("Hisaab") })
                        }
                    }
                ) { innerPadding ->
                    when (currentTab) {
                        0 -> DailyEntryScreen(viewModel, modifier = Modifier.padding(innerPadding))
                        1 -> HistoryScreen(viewModel, onEditRecord = { viewModel.onDateSelected(it.date); currentTab = 0 }, modifier = Modifier.padding(innerPadding))
                        2 -> SummaryScreen(viewModel, modifier = Modifier.padding(innerPadding))
                    }
                }
            }
        }
    }
}