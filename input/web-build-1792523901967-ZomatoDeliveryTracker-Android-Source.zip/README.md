# Zomato Delivery Tracker (Native Android)
Built with Kotlin, Jetpack Compose, Material 3, and Room Local Database.

### How to Run:
1. Open this unzipped folder in **Android Studio Hedgehog / Iguana / Jellyfish**.
2. Sync Gradle files.
3. Run on an Android Device or Android Emulator.
4. Works 100% offline with zero external dependencies!
