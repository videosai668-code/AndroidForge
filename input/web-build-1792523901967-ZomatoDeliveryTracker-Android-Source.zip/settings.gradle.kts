rootProject.name = "ZomatoDeliveryTracker"
include(":app")
